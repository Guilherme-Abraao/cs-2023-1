package EX1;

import java.util.Arrays;
import java.util.Random;

public class Teste {

    public static void main(String[] args) {
        int[] sizes = {100, 1000, 10000};

        for (int size : sizes) {
            int[] arr = generateRandomArray(size);
            int[] arrCopy = arr.clone();

            System.out.println("Array size: " + size);

            // Merge Sort Iterative
            long startTime = System.nanoTime();
            mergeSortIterative(arr);
            long endTime = System.nanoTime();
            long durationIterative = endTime - startTime;
            System.out.println("Merge Sort (Iterative) time: " + durationIterative + " nanoseconds");

            // Merge Sort Recursive
            startTime = System.nanoTime();
            mergeSortRecursive(arrCopy);
            endTime = System.nanoTime();
            long durationRecursive = endTime - startTime;
            System.out.println("Merge Sort (Recursive) time: " + durationRecursive + " nanoseconds");

            // Verificar se os arrays estão corretamente ordenados
            System.out.println("Arrays sorted correctly: " + Arrays.equals(arr, arrCopy));
            System.out.println();
        }
    }

    public static void mergeSortIterative(int[] arr) {
        // Implementação do Merge Sort Iterativo
        // ...
    }

    public static void mergeSortRecursive(int[] arr) {
        // Implementação do Merge Sort Recursivo
        // ...
    }

    public static int[] generateRandomArray(int size) {
        Random random = new Random();
        int[] arr = new int[size];

        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(1000);  // Valores aleatórios entre 0 e 999
        }

        return arr;
    }
}
