package EX1;

import java.util.Arrays;

public class MergeSortIterative {

    public static void mergeSortIterative(int[] arr) {
        int n = arr.length;
        int[] tempArray = new int[n];
        int subArraySize = 1;

        while (subArraySize < n) {
            int startIdx = 0;

            while (startIdx < n - 1) {
                int midIdx = Math.min(startIdx + subArraySize - 1, n - 1);
                int endIdx = Math.min(startIdx + 2 * subArraySize - 1, n - 1);

                merge(arr, tempArray, startIdx, midIdx, endIdx);

                startIdx += 2 * subArraySize;
            }

            subArraySize *= 2;
        }
    }

    public static void merge(int[] arr, int[] tempArray, int startIdx, int midIdx, int endIdx) {
        int i = startIdx;
        int j = midIdx + 1;
        int k = startIdx;

        while (i <= midIdx && j <= endIdx) {
            if (arr[i] <= arr[j]) {
                tempArray[k] = arr[i];
                i++;
            } else {
                tempArray[k] = arr[j];
                j++;
            }
            k++;
        }

        while (i <= midIdx) {
            tempArray[k] = arr[i];
            i++;
            k++;
        }

        while (j <= endIdx) {
            tempArray[k] = arr[j];
            j++;
            k++;
        }

        for (k = startIdx; k <= endIdx; k++) {
            arr[k] = tempArray[k];
        }
    }

    public static void main(String[] args) {
        int[] arr = {5, 2, 8, 12, 3, 7};
        System.out.println("Original array: " + Arrays.toString(arr));

        mergeSortIterative(arr);
        System.out.println("Sorted array: " + Arrays.toString(arr));
    }
}

