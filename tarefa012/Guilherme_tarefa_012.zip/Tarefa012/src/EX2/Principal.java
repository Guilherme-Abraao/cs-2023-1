package EX2;

public class Principal {
    public static void main(String[] args) {
        Agenda agenda = new Agenda();

        Contato contato1 = new Contato("João", "joao@example.com");
        Contato contato2 = new Contato("Maria", "maria@example.com");
        Contato contato3 = new Contato("Carlos", "carlos@example.com");

        agenda.adicionarContato(contato1);
        agenda.adicionarContato(contato2);
        agenda.adicionarContato(contato3);

        System.out.println("Lista de contatos:");
        agenda.listarContatos();

        System.out.println();

        String nomeBusca = "João";
        Contato contatoEncontrado = agenda.buscarContato(nomeBusca);
        if (contatoEncontrado != null) {
            System.out.println("Contato encontrado:");
            System.out.println("Nome: " + contatoEncontrado.getNome());
            System.out.println("Email: " + contatoEncontrado.getEmail());
        } else {
            System.out.println("Contato com nome \"" + nomeBusca + "\" não encontrado.");
        }

        System.out.println();

        String nomeExclusao = "Maria";
        agenda.excluirContato(nomeExclusao);
        System.out.println("Contato com nome \"" + nomeExclusao + "\" excluído.");

        System.out.println();
        
    }
}
