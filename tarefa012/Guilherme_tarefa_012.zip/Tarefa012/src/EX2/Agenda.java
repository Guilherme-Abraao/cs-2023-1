package EX2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class Agenda {
    private List<Contato> contatos;

    public Agenda() {
        contatos = new ArrayList<>();
    }

    public void adicionarContato(Contato contato) {
        contatos.add(contato);
    }

    public Contato buscarContato(String termo) {
        for (Contato contato : contatos) {
            if (contato.getNome().equals(termo) || contato.getEmail().equals(termo)) {
                return contato;
            }
        }
        return null;
    }

    public void excluirContato(String nome) {
        Iterator<Contato> iterator = contatos.iterator();
        while (iterator.hasNext()) {
            Contato contato = iterator.next();
            if (contato.getNome().equals(nome)) {
                iterator.remove();
                break;
            }
        }
    }

    public void listarContatos() {
        for (Contato contato : contatos) {
            System.out.println("Nome: " + contato.getNome() + ", Email: " + contato.getEmail());
        }
    }
}